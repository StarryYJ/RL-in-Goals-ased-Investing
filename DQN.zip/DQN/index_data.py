import pandas as pd
import numpy as np
from pandas_datareader import data


def Get_data(stock):
    dataset_1 = pd.DataFrame(data=stock['Adj Close'])
    dataset_2 = pd.DataFrame(data=stock['Low'])
    dataset_3 = pd.DataFrame(data=stock['High'])
    df1 = pd.DataFrame()
    df2 = pd.DataFrame()
    df3 = pd.DataFrame()
    for i in range(len(dataset_1.columns)):
        df1[i] = dataset_1.iloc[:, i]
        df2[i] = dataset_2.iloc[:, i]
        df3[i] = dataset_3.iloc[:, i]

        # RSI
        delta = df1[i].diff()
        up, down = delta.copy(), delta.copy()
        up[up < 0] = 0
        down[down > 0] = 0
        roll_up1 = up.ewm(span=14).mean()
        roll_down1 = down.abs().ewm(span=14).mean()

        RS = roll_up1 / roll_down1
        RSI = 100.0 - (100.0 / (1.0 + RS))
        index_data = pd.DataFrame(RSI[31:])
        index_data.columns = ['RSI']

        # SR
        SR = []
        data1 = df1[i]
        for j in range(31, len(data1)):
            dat = data1[j - 30:j]
            returns = (dat - dat.shift(1) / dat.shift(1))
            SR1 = (returns.mean() / returns.std())
            SR.append(SR1)
        SR = np.array(SR)
        index_data['SR'] = SR

        # EWM
        EWM = data1.ewm(span=20, adjust=False).mean()
        index_data['EWM'] = EWM[31:]

        # MA,window=20
        index_data['MA20'] = data1.rolling(window=20).mean()
        index_data['MA5'] = data1.rolling(window=5).mean()
        index_data['MA13'] = data1.rolling(window=13).mean()

        # KDJ
        low_list = df2[i].rolling(9, min_periods=9).min()
        low_list.fillna(value=df2[i].expanding().min(), inplace=True)
        high_list = df3[i].rolling(9, min_periods=9).max()
        high_list.fillna(value=df3[i].expanding().max(), inplace=True)

        rsv = abs((df1[i] - low_list) / (high_list - low_list) * 100)

        index_data['K'] = pd.DataFrame(rsv).ewm(com=2).mean()
        index_data['D'] = index_data['K'].ewm(com=2).mean()
        index_data['J'] = 3 * index_data['K'] - 2 * index_data['D']

        # BOLL
        index_data['20dSTD'] = data1.rolling(window=20).std()

        index_data['Upper'] = index_data['MA20'] + (index_data['20dSTD'] * 2)
        index_data['Lower'] = index_data['MA20'] - (index_data['20dSTD'] * 2)

        return index_data
