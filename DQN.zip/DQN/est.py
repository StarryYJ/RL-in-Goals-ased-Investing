# from maze_env import Maze
from stock_env import stock
from index_data import Get_data
from Agent import DeepQNetwork
import pandas as pd
from pandas_datareader import data
import numpy as np
import sys
import os
from scipy.optimize import minimize
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import tensorflow as tf
from scipy import stats
start_date = "2011-01-01"
end_date = "2020-12-31"

def lighten_color(color, amount=0.5):
    """
    Lightens the given color by multiplying (1-luminosity) by the given amount.
    Input can be matplotlib color string, hex string, or RGB tuple.

    Examples:
    >> lighten_color('g', 0.3)
    >> lighten_color('#F034A3', 0.6)
    >> lighten_color((.3,.55,.1), 0.5)
    """
    import matplotlib.colors as mc
    import colorsys
    try:
        c = mc.cnames[color]
    except:
        c = color
    c = colorsys.rgb_to_hls(*mc.to_rgb(c))
    return colorsys.hls_to_rgb(c[0], 1 - amount * (1 - c[1]), c[2])

def download_stock(stock_tick):
    panel_data1 = data.DataReader(stock_tick, "yahoo", start_date, end_date)
    stock_tick = pd.DataFrame(data=panel_data1['Adj Close'])
    return stock_tick, panel_data1


NVDA, full_NVDA = download_stock('NVDA')
AMD, full_AMD = download_stock('NTDOY')
TTWO, full_TTWO = download_stock('TTWO')
EA, full_EA = download_stock('EA')
ATVI, full_ATVI = download_stock('ATVI')

ETF,full_ETF = download_stock('ESPO')


def get_train_test(df):
    global stage_1_training, stage_1_testing
    for i in range(len(df)):
        if str(df.index[i]) == '2017-12-29 00:00:00':
            stage_1_training = df.iloc[:i + 1, :]
            stage_1_testing = df.iloc[i + 1:, :]
    return pd.DataFrame(stage_1_training), pd.DataFrame(stage_1_testing)


train_NVDA, test_NVDA = get_train_test(NVDA)
train_AMD, test_AMD = get_train_test(AMD)
train_TTWO, test_TTWO = get_train_test(TTWO)
train_EA, test_EA = get_train_test(EA)
train_ATVI, test_ATVI = get_train_test(ATVI)

train_ETF, test_ETF = get_train_test(ETF)

def game_step(env, RL, observation, step=None, train=True, show_log=False, my_trick=False):
    # RL choose action based on observation
    action = RL.choose_action(observation, train)

    # RL take action and get next observation and reward
    observation_, reward, done = env.step(action, show_log=show_log, my_trick=my_trick)

    RL.store_transition(observation, action, reward, observation_)
    # print("total profit:%.3f" % env.total_profit, end='\r')
    if step and (step > 3000) and (step % 8 == 0):
        RL.learn()

    # swap observation
    observation = observation_

    return observation, done


def adjust_weight(step, env_lst, weights=None):
    if step == 0:
        weights = [1 / len(env_lst)] * len(env_lst)
        return weights

    elif step != 0 and step % 15 == 0:
        rate_accounts = []
        rate_stocks = []
        for e in env_lst:
            rate_accounts.append(e.profit_rate_account[-15:])
            rate_stocks.append(e.profit_rate_stock[-15:])
        Sigma_accounts = pd.DataFrame(rate_accounts).T.cov()
        Sigma_stocks = pd.DataFrame(rate_stocks).T.cov()
        exp_r_acc = pd.DataFrame(rate_accounts).pct_change().apply(np.mean, axis=1)
        exp_r_sto = pd.DataFrame(rate_stocks).pct_change().apply(np.mean, axis=1)

        def goal(omega):
            risk_prefer = 0.4
            return - omega.T.dot(exp_r_sto) + (1 - risk_prefer) * omega.T.dot(Sigma_stocks).dot(omega)

        bounds = []
        for n in range(len(weights)):
            bounds.append((0.0, 1))

        def cons(omega):
            return sum(omega) - 1

        constraint = [{'type': 'eq', 'fun': cons}]

        opt_w = minimize(goal, weights, bounds=bounds, constraints=constraint, method='SLSQP')
        return opt_w.x
    else:
        return None


def run(env_list, max_round):
    step = 0
    total_profit_max = 0
    total_profit_round = 0
    for episode in range(max_round):
        profit = 0
        # initial observation
        observation1 = env_list[0].reset()
        observation2 = env_list[1].reset()
        observation3 = env_list[2].reset()
        observation4 = env_list[3].reset()
        observation5 = env_list[4].reset()

        weight_lst = [[1 / len(env_list)] * len(env_list)]
        k = 0

        while True:

            new_weight = adjust_weight(step, env_lst=env_list, weights=weight_lst[k])

            if step == 0:
                money = [sum([env_list[j].init_money for j in range(len(env_list))])] * 5
            else:
                money = [sum([env_list[j].maket_value for j in range(len(env_list))])] * 5
                # print(money)


            for j in range(len(env_list)):
                if new_weight is not None:

                    # print([money[m] * new_weight[m] for m in range(len(new_weight))])
                    env_list[0].init_money, env_list[1].init_money, env_list[2].init_money,env_list[3].init_money,env_list[4].init_money = [money[m] * new_weight[m] for m in
                                                                      range(len(new_weight))]
                    env_list[0].hold_money = env_list[0].init_money - env_list[0].stock_value
                    env_list[0].maket_value = env_list[0].hold_money + env_list[0].stock_value

                    env_list[1].hold_money = env_list[1].init_money - env_list[1].stock_value
                    env_list[1].maket_value = env_list[1].hold_money + env_list[1].stock_value

                    env_list[2].hold_money = env_list[2].init_money - env_list[2].stock_value
                    env_list[2].maket_value = env_list[2].hold_money + env_list[2].stock_value

                    env_list[3].hold_money = env_list[3].init_money - env_list[3].stock_value
                    env_list[3].maket_value = env_list[3].hold_money + env_list[3].stock_value

                    env_list[4].hold_money = env_list[4].init_money - env_list[4].stock_value
                    env_list[4].maket_value = env_list[4].hold_money + env_list[4].stock_value
                    # print(env_list[0].last_value)

            observation1, done1 = game_step(env_list[0], Agent1, observation1, step=step)
            observation2, done2 = game_step(env_list[1], Agent2, observation2, step=step)
            observation3, done3 = game_step(env_list[2], Agent3, observation3, step=step)
            observation4, done2 = game_step(env_list[3], Agent2, observation4, step=step)
            observation5, done3 = game_step(env_list[4], Agent3, observation5, step=step)

            if done1:
                break
            step += 1
        profit += env_list[0].total_profit + env_list[1].total_profit
        print('epoch:%d, total_profit:%.3f' % (episode, profit))

        total_profit = 0

        BackTest(env_list2[0], Agent1, show_log=False, my_trick=True)
        total_profit += env_list2[0].total_profit

        BackTest(env_list2[1], Agent2, show_log=False, my_trick=True)
        total_profit += env_list2[1].total_profit

        BackTest(env_list2[2], Agent3, show_log=False, my_trick=True)
        total_profit += env_list2[2].total_profit

        BackTest(env_list2[3], Agent3, show_log=False, my_trick=True)
        total_profit += env_list2[3].total_profit

        BackTest(env_list2[4], Agent3, show_log=False, my_trick=True)
        total_profit += env_list2[4].total_profit

        print(total_profit)
        if total_profit_max < total_profit:
            total_profit_max = total_profit
            total_profit_round = episode
    print(total_profit_round)


def BackTest(env, RL, show_log=True, my_trick=False):
    observation = env.reset()
    # step=0
    while True:
        observation, done = game_step(env, RL, observation, train=False,
                                      show_log=show_log, my_trick=my_trick)
        # break while loop when end of this episode
        if done:
            break


# if __name__ == "__main__":
tf.compat.v1.reset_default_graph()
max_round = 16

index_data1 = Get_data(full_NVDA)
index_data2 = Get_data(full_AMD)
index_data3 = Get_data(full_TTWO)
index_data4 = Get_data(full_EA)
index_data5 = Get_data(full_ATVI)

index_data12 = Get_data(full_NVDA.iloc[-len(test_NVDA):, :])
index_data22 = Get_data(full_AMD.iloc[-len(test_AMD):, :])
index_data32 = Get_data(full_TTWO.iloc[-len(test_TTWO):, :])
index_data42 = Get_data(full_AMD.iloc[-len(test_EA):, :])
index_data52 = Get_data(full_TTWO.iloc[-len(test_ATVI):, :])


env_list = []
env_list2 = []

env_list.append(stock(train_NVDA[31:], index_data1))
env_list.append(stock(train_AMD[31:], index_data2))
env_list.append(stock(train_TTWO[31:], index_data3))
env_list.append(stock(train_EA[31:], index_data2))
env_list.append(stock(train_ATVI[31:], index_data3))

env_list2.append(stock(test_NVDA[31:], index_data12))
env_list2.append(stock(test_AMD[31:], index_data22))
env_list2.append(stock(test_TTWO[31:], index_data32))
env_list2.append(stock(test_EA[31:], index_data22))
env_list2.append(stock(test_ATVI[31:], index_data32))


Agent1 = DeepQNetwork(env_list[0].n_actions, env_list[0].n_features,
                      learning_rate=0.0002,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=300,
                      memory_size=7000,
                      batch_size=256,
                      series=0
                      )
Agent2 = DeepQNetwork(env_list[1].n_actions, env_list[0].n_features,
                      learning_rate=0.0002,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=300,
                      memory_size=7000,
                      batch_size=256,
                      series=1
                      )

Agent3 = DeepQNetwork(env_list[2].n_actions, env_list[0].n_features,
                      learning_rate=0.0002,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=300,
                      memory_size=7000,
                      batch_size=256,
                      series=2
                      )

Agent4 = DeepQNetwork(env_list[3].n_actions, env_list[0].n_features,
                      learning_rate=0.0002,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=300,
                      memory_size=7000,
                      batch_size=256,
                      series=3
                      )

Agent5 = DeepQNetwork(env_list[4].n_actions, env_list[0].n_features,
                      learning_rate=0.0002,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=300,
                      memory_size=7000,
                      batch_size=256,
                      series=4
                      )

run(env_list, max_round=max_round)
# i = 0
# BackTest(env_list2[0], Agent1, show_log=False)
# name1 = 'plots/trade1_' + str(i) + str(max_round) + '.png'
# name2 = 'plots/profit1_' + str(i) + str(max_round) + \
#         '.png'
# env_list2[0].draw(name1, name2)
# print('total_profit:%.3f' % (env_list2[0].total_profit))
# i = i + 1
#
# BackTest(env_list2[1], Agent2, show_log=False)
# name1 = 'plots/trade1_' + str(i) + str(max_round) + '.png'
# name2 = 'plots/profit1_' + str(i) + str(max_round) + '.png'
# env_list2[1].draw(name1, name2)
# print('total_profit:%.3f' % (env_list2[1].total_profit))
#
# # env.draw('trade1.png', 'profit1.png')
# i = 0
# for env in env_list2:
#     BackTest(env, show_log=False, my_trick=True)
#     name1 = 'plots/trade2_' + str(i) + '.png'
#     name2 = 'plots/profit2_' + str(i) + '.png'
#     env.draw(name1, name2)
#     print('total_profit:%.3f' % (env.total_profit))
#     i = i + 1

ddpg_data = pd.read_csv(r'C:\Users\康铭昊\Desktop\2020 fall\pythonProject2\plot\Weights\ddpg.csv')


dt = [env_list2[0].profit_rate_account[i] + env_list2[1].profit_rate_account[i] for
      i in range(len(env_list2[0].profit_rate_account))]
plt.plot(dt, label = 'protfolio', linewidth = 3, color= 'indianred')
plt.plot(env_list2[0].profit_rate_stock, label = 'NVDA', ls= '--',color=lighten_color('r', 0.4))
plt.plot(env_list2[1].profit_rate_stock, label= 'AMD',ls= '--',color=lighten_color('b', 0.4))
plt.plot(env_list2[2].profit_rate_stock, label='TTWO',ls= '--',color=lighten_color('y', 0.4))
plt.plot(env_list2[3].profit_rate_stock, label= 'EA',ls= '--',color=lighten_color('green', 0.4))
plt.plot(env_list2[4].profit_rate_stock, label='ATVI',ls= '--',color=lighten_color('gray', 0.4))
# plt.plot(test_ETF, label='ETF',linewidth = 3, color=lighten_color('orange', 0.4))
# plt.plot(env_list2[1].profit_rate_stock, label='TSLA')
# plt.plot(env_list2[1].profit_rate_stock, label='TSLA')
plt.legend()
plt.show()


# plt.plot(dt, label = 'protfolio', linewidth = 2, color= 'indianred')
# plt.plot(test_ETF, label = 'NVDA', ls= '--',color=lighten_color('b', 0.4))
# plt.legend()
# plt.show()

def maximum_10_drawdown(returns):
    max_dd = 0
    for i in range(len(returns) - 10):
        ten_day = returns[i:i + 10]
        max = np.max(ten_day)
        min = np.min(ten_day)
        dd_10 = (max - min) / min
        max_dd = np.max(np.array([dd_10, max_dd]))
    return max_dd


def sample_para_VaR(data, size):
    sample = np.random.choice(data, size, replace=True)
    VaR_5 = np.percentile(sample, 5)
    return VaR_5


def insert_series(series):
    new_series = [i for i in range(len(series))]
    n = len(series)
    steps = int(n / 5)
    ranges = list(np.arange(0, len(series), step=steps))
    for i in range(len(new_series)):
        if i in ranges:
            new_series[i] = series[i]
        else:
            new_series[i] = ''
            if i == n - 1:
                new_series[i] = series[i]
    return new_series


# df
def output_statistics(strategy, benchmark,len):
    strategy_cum = strategy
    benchmark_cum = benchmark
    cumulative_return = [strategy_cum[len], benchmark_cum[len]]
    average_return = [250 * np.mean(strategy), 250 * np.mean(benchmark)]
    standard_deviation = [np.sqrt(250) * np.std(strategy), np.sqrt(250) * np.std(benchmark)]
    max_DD = [maximum_10_drawdown(strategy_cum + 1), maximum_10_drawdown(benchmark_cum + 1)]
    skewness = [stats.skew(strategy), stats.skew(benchmark)]
    kurtosis = [stats.kurtosis(strategy), stats.kurtosis(benchmark)]
    VaR = [sample_para_VaR(strategy, len(strategy)), sample_para_VaR(benchmark, len(benchmark))]
    out_df = pd.DataFrame([cumulative_return, average_return, standard_deviation,
                           max_DD, skewness, kurtosis, VaR])
    out_df.columns = ['DQN', 'ETF EPSO']
    out_df.index = ['cumulative_return', 'average_return', 'standard_deviation', 'max_DD', 'skewness',
                    'kurtosis', 'VaR']
    return out_df

def maximum_10_drawdown1(returns):
    max_dd = 0
    for i in range(len(returns) - 10):
        ten_day = returns[i:i + 10]
        max_ = np.max(ten_day)
        min_ = np.min(ten_day)
        dd_10 = (max_ - min_) / min_
        max_dd = np.max(np.array([dd_10, max_dd]))
    return max_dd


def sample_para_VaR1(data):
    VaR_5 = np.percentile(data, 5)
    return VaR_5


def insert_series1(series):
    new_series = [i for i in range(len(series))]
    n = len(series)
    steps = int(n / 5)
    ranges = list(np.arange(0, len(series), step=steps))
    for i in range(len(new_series)):
        if i in ranges:
            new_series[i] = series[i]
        else:
            new_series[i] = ''
            if i == n - 1:
                new_series[i] = series[i]
    return new_series
def output_statistics1(strategy, benchmark):
    strategy_cum = (np.cumprod(np.array(strategy) + 1))
    benchmark_cum = (np.cumprod(np.array(benchmark)))
    PnL = [strategy_cum[-1], benchmark_cum[-1]]
    average_return = [np.mean(strategy), np.mean(benchmark) - 1]
    standard_deviation = [np.std(strategy), np.std(benchmark)]
    max_DD = [maximum_10_drawdown(strategy_cum + 1), maximum_10_drawdown(benchmark_cum + 1)]
    skewness = [stats.skew(strategy), stats.skew(benchmark)]
    kurtosis = [stats.kurtosis(strategy), stats.kurtosis(benchmark)]
    VaR = [sample_para_VaR1(strategy), sample_para_VaR1([i - 1 for i in benchmark])]
    out_df = pd.DataFrame([np.round(PnL,3), np.round(average_return, 3), np.round(standard_deviation, 3),
                           np.round(max_DD,3), np.round(skewness,3), np.round(kurtosis,3), np.round(VaR,3)])
    out_df.columns = ['strategy', 'benchmark']
    out_df.index = ['PnL', 'Daily Mean Arithmetic', 'Volatility', 'Max 10 days draw down', 'Skewness', 'Kurtosis',
                    'VaR']
    return out_df

aaaa = data.DataReader('ESPO', "yahoo", start_date, end_date)

test_ETF = aaaa.iloc[-705:, :]
# ETF_re = [1]
ETF_re = [1]
len(test_ETF)
for i in range(len(test_ETF)-1):
    temp = (test_ETF['Close'][i+1] - test_ETF['Close'][i]) /test_ETF['Close'][i]
    ETF_re.append(round(temp + 1, 3))
len(ETF_re)

len(env_list2[0].profit_rate_stock)


portfolio = [1]
benchmark = [1]
port, bench = (1 + ddpg_data['port']), ddpg_data['bench']
for i in range(len(ddpg_data['port'])):
    port *= (1 + ddpg_data['port'][i])
    bench *= ddpg_data['bench'][i]
    portfolio.append(port)
    benchmark.append(bench)

len(portfolio)
len(dt)

plt.plot(dt[10:], label = 'DQN', linewidth = 1, color= 'indianred')
plt.plot(portfolio, label = 'DDPG',linewidth = 1, color= 'g')
# plt.plot(ddpg_data['bench'], label='BenchMark', linewidth=1, color='b')
plt.legend()
plt.show()
dt = [env_list2[0].profit_rate_account[i] + env_list2[1].profit_rate_account[i] + env_list2[2].profit_rate_account[i] + env_list2[3].profit_rate_account[i] + env_list2[4].profit_rate_account[i]for
      i in range(len(env_list2[0].profit_rate_account))]
#
# dt.to_csv(r'C:\Users\康铭昊\Desktop\2020 fall\pythonProject2\plot\Weights\dt.csv')


# dt = pd.DataFrame(dt[10:])
# dt.columns = ['rt']

dt = dt[10:]
len(ETF_re)
len(dt)
for i in range(len(dt)+1):
    dt[i] += 1
    ETF_re[i] += 1

dt = pd.DataFrame(dt)

output_statistics1(dt, ETF_re)
for i in range(705):
    dt[i] +=1

# dt.to_csv(r'C:\Users\康铭昊\Desktop\2020 fall\pythonProject2\plot\Weights\dt.csv')
ETF_re = pd.DataFrame(ETF_re)
ETF_re.columns = ['rt']
ETF_re.to_csv(r'C:\Users\康铭昊\Desktop\2020 fall\pythonProject2\plot\Weights\ETF.csv')
(np.cumprod(np.array(ETF_re) ))


temp = []
prod = 1
for i in range(0, 705):
    prod *= ETF_re[i]
    temp.append(prod)








